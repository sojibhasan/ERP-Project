<?php

namespace App\Chequer;

use Illuminate\Database\Eloquent\Model;

class ChequerCurrency extends Model
{
    //
}
