<?php

namespace Illuminate\Redis\Connections;

/**
 * @deprecated Predis is no longer maintained by its original author
 */
class PredisClusterConnection extends PredisConnection
{
    //
}
