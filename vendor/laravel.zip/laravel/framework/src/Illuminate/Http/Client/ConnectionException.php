<?php

namespace Illuminate\Http\Client;

use Exception;

class ConnectionException extends Exception
{
    //
}
