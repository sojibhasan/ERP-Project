<?php

return [
    'name' => 'Property'
];
