<?php

namespace Modules\Property\Entities;

use Illuminate\Database\Eloquent\Model;

class BlockCloseReason extends Model
{
    protected $fillable = [];

    protected $guarded = ['id'];
}
