<?php
namespace Modules\Property\Entities;

use Illuminate\Database\Eloquent\Model;

class InstallmentCycle extends Model
{
    protected $fillable = [];

    protected $guarded = ['id'];
}
