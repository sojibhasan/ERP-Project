<?php

namespace Modules\Property\Entities;

use Illuminate\Database\Eloquent\Model;

class PropertyTax extends Model
{
    protected $fillable = [];
    protected $guarded = ['id'];
}
