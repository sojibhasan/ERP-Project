<?php

namespace Modules\Property\Entities;

use Illuminate\Database\Eloquent\Model;

class PaymentOption extends Model
{
    protected $fillable = [];
    
    protected $guarded = ['id'];
}
