<?php

namespace Modules\Property\Entities;

use Illuminate\Database\Eloquent\Model;

class Installment extends Model
{
    protected $fillable = [];

    protected $guarded = ['id'];
}
