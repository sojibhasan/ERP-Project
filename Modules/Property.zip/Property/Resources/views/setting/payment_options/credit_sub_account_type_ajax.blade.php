{!! Form::select('credit_account', $accounts, null,
            ['placeholder' => __( 'property::lang.select_account' ),
             'required',
             'class' => 'form-control',
              ]); !!}