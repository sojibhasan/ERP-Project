<span id="view_contact_page"></span>
<div class="row">
    <div class="col-md-12">
        <div class="col-sm-3">
            @include('petro::pump_operators.contact_basic_info')
        </div>
    </div>
</div>